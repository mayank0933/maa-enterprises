import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  Undo2, Redo2, Save, Download, Printer, Plus, Trash2, Upload, X,
  ZoomIn, ZoomOut, Check, ChevronDown, ChevronUp, FolderOpen, Copy,
  AlertTriangle, ArrowLeft, User, RefreshCw, Palette, LayoutTemplate,
  Eye, PenLine, Image as ImageIcon
} from "lucide-react";

/* ----------------------------------------------------------------------
   CONSTANTS
---------------------------------------------------------------------- */

const OBJECTIVES = [
  "Secure a responsible career opportunity to fully utilize my talent and skills to grow, while making a significant contribution to the success of the company.",
  "Self-motivated and hardworking fresher seeking an opportunity to work in a challenging environment to prove my skills and utilize my knowledge and intelligence in the growth of the organization.",
  "Urge for a position in an aggressively growing organization where my technical and functional expertise can be effectively utilized, possessing good analytical abilities, quick grasping power, zeal for learning new things and excellent communication skills.",
  "To seek a good and responsible job in a professionally managed organization where my conceptual and functional skills are effectively utilized in a way that contributes to organizational growth coupled with personal growth.",
  "To make a good position in a reputed company and work enthusiastically in a team which provides steady career growth along with job satisfaction, challenges and valuable contribution to the success of the organization.",
  "To contribute my best to the organization irrespective of the kind of project undertaken and utilize my skills to perform the job to the best of my ability with zeal and willingness to learn.",
];

const DECLARATIONS = [
  "I hereby declare that all the statements made in this resume are true, complete and correct to the best of my knowledge.",
  "I hereby declare that the information provided above is true and correct to the best of my knowledge and belief.",
  "I declare that the information furnished above is true and accurate to the best of my knowledge.",
];

const COLORS = [
  { name: "Navy", hex: "#1B3A5C" },
  { name: "Blue", hex: "#2563EB" },
  { name: "Teal", hex: "#0F766E" },
  { name: "Green", hex: "#15803D" },
  { name: "Maroon", hex: "#8B1E2E" },
  { name: "Red", hex: "#B91C1C" },
  { name: "Purple", hex: "#6D28D9" },
  { name: "Orange", hex: "#C2560D" },
  { name: "Gray", hex: "#374151" },
  { name: "Black", hex: "#111111" },
];

const TEMPLATES = [
  { id: "classic", name: "Classic", desc: "Traditional centered header, serif type — the familiar Indian CV look." },
  { id: "modern", name: "Modern", desc: "Bold colored header band, clean sans-serif, corporate feel." },
  { id: "sidebar", name: "Sidebar", desc: "Left color sidebar for photo & contact, content on the right." },
  { id: "minimal", name: "Minimal", desc: "Quiet black & gray, accent used sparingly for a sharp, modern look." },
];

const LEVELS = [
  { id: "low", name: "Low Details", desc: "A simple, one-page professional resume — ideal for freshers and basic job applications." },
  { id: "medium", name: "Medium Details", desc: "Adds skills, projects, certifications & more — for candidates with extra qualifications." },
  { id: "high", name: "High Details", desc: "The full professional CV — for engineers, IT professionals & experienced corporate candidates." },
];

const todayISO = () => new Date().toISOString().slice(0, 10);
const uid = () => Math.random().toString(36).slice(2, 10);
const currentYear = new Date().getFullYear();

/* ----------------------------------------------------------------------
   DATA MODEL — one shared shape for every template & every level
---------------------------------------------------------------------- */

function emptyResume() {
  return {
    personal: {
      photo: null, photoZoom: 1, photoX: 50, photoY: 50,
      fullName: "", address: "", mobile: "", whatsapp: "",
      dob: "", fatherName: "", motherName: "", nationality: "Indian",
      gender: "", maritalStatus: "", email: "",
      languagesKnown: "", hobbies: "",
    },
    objectiveSelected: [],
    objectiveText: "",
    education: [
      { id: uid(), exam: "High School / 10th", board: "", year: "", marks: "", division: "" },
      { id: uid(), exam: "Intermediate / 12th", board: "", year: "", marks: "", division: "" },
      { id: uid(), exam: "Graduation", board: "", year: "", marks: "", division: "" },
    ],
    professionalQualification: [],
    extraQualification: [],
    isFresher: true,
    experience: [],
    summary: "",
    skills: [],
    technicalSkills: [],
    programmingLanguages: [],
    tools: [],
    certifications: [],
    projects: [],
    achievements: [],
    languages: [],
    strengths: [],
    training: [],
    internship: [],
    references: [],
    declarationSelected: DECLARATIONS[0],
    declarationCustom: "",
    useCustomDeclaration: false,
    footer: { date: todayISO(), place: "", signatureName: "", signatureImg: null },
  };
}

/* ----------------------------------------------------------------------
   VALIDATION HELPERS
---------------------------------------------------------------------- */

const isValidMobile = (v) => !v || /^[6-9]\d{9}$/.test(v.replace(/\D/g, ""));
const isValidEmail = (v) => !v || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isValidYear = (v) => !v || (/^\d{4}$/.test(v) && +v >= 1950 && +v <= currentYear + 1);
const isValidPercentage = (v) => !v || (!isNaN(+v) && +v >= 0 && +v <= 100);
const isValidDOB = (v) => !v || new Date(v) <= new Date();

/* ----------------------------------------------------------------------
   PERSISTENT STORAGE (window.storage — never localStorage in artifacts)
---------------------------------------------------------------------- */

async function storageGet(key) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}
async function storageSet(key, value) {
  try { window.localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch (e) { return false; }
}
async function storageDelete(key) {
  try { window.localStorage.removeItem(key); return true; }
  catch (e) { return false; }
}

/* ----------------------------------------------------------------------
   SMALL UI PRIMITIVES
---------------------------------------------------------------------- */

function Field({ label, error, hint, required, children }) {
  return (
    <label className="block mb-3">
      <span className="block text-xs font-medium text-slate-600 mb-1">
        {label}{required && <span className="text-red-500"> *</span>}
      </span>
      {children}
      {error && <span className="block text-xs text-red-600 mt-1">{error}</span>}
      {!error && hint && <span className="block text-xs text-slate-400 mt-1">{hint}</span>}
    </label>
  );
}

const inputCls = "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-[15px] text-slate-800 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200 transition";

function TextInput(props) {
  const { error, ...rest } = props;
  return <input {...rest} className={inputCls + (error ? " border-red-400" : "") + (props.className ? " " + props.className : "")} />;
}
function TextArea(props) {
  return <textarea {...props} className={inputCls + " min-h-[90px] resize-y" + (props.className ? " " + props.className : "")} />;
}

function SectionCard({ title, subtitle, defaultOpen = true, children, badge }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-xl border border-slate-200 bg-white mb-3 overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between px-4 py-3.5 text-left"
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800 text-[15px]">{title}</span>
            {badge}
          </div>
          {subtitle && <span className="text-xs text-slate-400">{subtitle}</span>}
        </div>
        {open ? <ChevronUp size={18} className="text-slate-400 shrink-0" /> : <ChevronDown size={18} className="text-slate-400 shrink-0" />}
      </button>
      {open && <div className="px-4 pb-4 pt-1 border-t border-slate-100">{children}</div>}
    </div>
  );
}

function TagInput({ items, onChange, placeholder }) {
  const [val, setVal] = useState("");
  const add = () => {
    const v = val.trim();
    if (v) { onChange([...items, v]); setVal(""); }
  };
  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-2">
        {items.map((t, i) => (
          <span key={i} className="inline-flex items-center gap-1 bg-slate-100 text-slate-700 text-sm px-2.5 py-1 rounded-full">
            {t}
            <button type="button" onClick={() => onChange(items.filter((_, idx) => idx !== i))} className="text-slate-400 hover:text-red-500">
              <X size={13} />
            </button>
          </span>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(); } }}
          placeholder={placeholder || "Type and press Enter"}
          className={inputCls}
        />
        <button type="button" onClick={add} className="shrink-0 rounded-lg bg-slate-800 text-white px-3.5 py-2.5 text-sm font-medium hover:bg-slate-700">
          Add
        </button>
      </div>
    </div>
  );
}

/** Generic card-based repeater for structured multi-field sections. */
function CardRepeater({ items, onChange, fields, addLabel, empty }) {
  const update = (id, key, value) => onChange(items.map((it) => (it.id === id ? { ...it, [key]: value } : it)));
  const remove = (id) => onChange(items.filter((it) => it.id !== id));
  const add = () => {
    const blank = { id: uid() };
    fields.forEach((f) => (blank[f.key] = ""));
    onChange([...items, blank]);
  };
  return (
    <div>
      {items.length === 0 && <p className="text-sm text-slate-400 mb-3">{empty}</p>}
      <div className="space-y-3">
        {items.map((it, idx) => (
          <div key={it.id} className="rounded-lg border border-slate-200 p-3 relative bg-slate-50/60">
            <button type="button" onClick={() => remove(it.id)} className="absolute top-2 right-2 text-slate-400 hover:text-red-500" aria-label="Delete entry">
              <Trash2 size={16} />
            </button>
            <div className="grid grid-cols-2 gap-2 pr-6">
              {fields.map((f) => (
                <div key={f.key} className={f.full ? "col-span-2" : ""}>
                  <span className="block text-[11px] text-slate-500 mb-1">{f.label}</span>
                  {f.type === "textarea" ? (
                    <TextArea value={it[f.key] || ""} onChange={(e) => update(it.id, f.key, e.target.value)} placeholder={f.placeholder} />
                  ) : (
                    <input
                      type={f.type || "text"}
                      value={it[f.key] || ""}
                      onChange={(e) => update(it.id, f.key, e.target.value)}
                      placeholder={f.placeholder}
                      className={inputCls}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <button type="button" onClick={add} className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-slate-700 border border-dashed border-slate-300 rounded-lg px-3 py-2 hover:bg-slate-50">
        <Plus size={15} /> {addLabel}
      </button>
    </div>
  );
}

/* ----------------------------------------------------------------------
   TOAST
---------------------------------------------------------------------- */
function Toast({ toast }) {
  if (!toast) return null;
  return (
    <div className={
      "fixed bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-[100] px-4 py-2.5 rounded-full text-sm font-medium shadow-lg " +
      (toast.type === "error" ? "bg-red-600 text-white" : "bg-slate-900 text-white")
    }>
      {toast.msg}
    </div>
  );
}

/* ----------------------------------------------------------------------
   MAIN APP
---------------------------------------------------------------------- */

export default function App() {
  const [screen, setScreen] = useState("home"); // home | level | editor
  const [level, setLevel] = useState("low");
  const [data, setData] = useState(emptyResume());
  const [template, setTemplate] = useState("classic");
  const [color, setColor] = useState(COLORS[0]);
  const [resumeName, setResumeName] = useState("Untitled Resume");
  const [currentId, setCurrentId] = useState(null);

  const [history, setHistory] = useState([]);
  const [histIdx, setHistIdx] = useState(-1);
  const skip = useRef(false);
  const pushTimer = useRef(null);

  const [mobileTab, setMobileTab] = useState("form"); // form | preview
  const [zoom, setZoom] = useState(0.42);
  const [toast, setToast] = useState(null);
  const [savedList, setSavedList] = useState([]);
  const [showLibrary, setShowLibrary] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [saveStatus, setSaveStatus] = useState("idle"); // idle | saving | saved
  const [confirm, setConfirm] = useState(null); // { msg, onYes }

  const showToast = useCallback((msg, type = "ok") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2200);
  }, []);

  /* ---------- history (undo/redo) ---------- */
  const snapshot = useCallback(() => JSON.stringify({ data, template, color, level, resumeName }), [data, template, color, level, resumeName]);

  useEffect(() => {
    if (screen !== "editor") return;
    if (skip.current) { skip.current = false; return; }
    clearTimeout(pushTimer.current);
    pushTimer.current = setTimeout(() => {
      setHistory((h) => {
        const cut = h.slice(0, histIdx + 1);
        const snap = snapshot();
        if (cut[cut.length - 1] === snap) return h;
        const next = [...cut, snap].slice(-60);
        setHistIdx(next.length - 1);
        return next;
      });
    }, 500);
    return () => clearTimeout(pushTimer.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, template, color, level, resumeName, screen]);

  const applySnap = (snap) => {
    const s = JSON.parse(snap);
    skip.current = true;
    setData(s.data); setTemplate(s.template); setColor(s.color); setLevel(s.level); setResumeName(s.resumeName);
  };

  const undo = useCallback(() => {
    if (histIdx > 0) { applySnap(history[histIdx - 1]); setHistIdx(histIdx - 1); }
  }, [history, histIdx]);
  const redo = useCallback(() => {
    if (histIdx < history.length - 1) { applySnap(history[histIdx + 1]); setHistIdx(histIdx + 1); }
  }, [history, histIdx]);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && !e.shiftKey) { e.preventDefault(); undo(); }
      if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === "y" || (e.key.toLowerCase() === "z" && e.shiftKey))) { e.preventDefault(); redo(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]);

  /* ---------- autosave ---------- */
  const autosaveTimer = useRef(null);
  useEffect(() => {
    if (screen !== "editor") return;
    setSaveStatus("saving");
    clearTimeout(autosaveTimer.current);
    autosaveTimer.current = setTimeout(async () => {
      const id = currentId || uid();
      if (!currentId) setCurrentId(id);
      const ok = await storageSet("resume:" + id, { id, name: resumeName, level, template, color, data, updatedAt: Date.now() });
      if (ok) {
        setSaveStatus("saved");
        await refreshIndex(id, resumeName, level);
      } else setSaveStatus("idle");
    }, 900);
    return () => clearTimeout(autosaveTimer.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, template, color, level, resumeName, screen]);

  const refreshIndex = async (id, name, lvl) => {
    const idx = (await storageGet("resumes-index")) || [];
    const without = idx.filter((r) => r.id !== id);
    const next = [{ id, name, level: lvl, updatedAt: Date.now() }, ...without];
    await storageSet("resumes-index", next);
  };

  const loadLibrary = async () => {
    const idx = (await storageGet("resumes-index")) || [];
    setSavedList(idx.sort((a, b) => b.updatedAt - a.updatedAt));
    setShowLibrary(true);
  };

  const openResume = async (id) => {
    const r = await storageGet("resume:" + id);
    if (!r) { showToast("Could not open that resume.", "error"); return; }
    skip.current = true;
    setData(r.data); setTemplate(r.template); setColor(r.color); setLevel(r.level);
    setResumeName(r.name); setCurrentId(r.id);
    setHistory([]); setHistIdx(-1);
    setShowLibrary(false); setScreen("editor");
    showToast("Resume loaded");
  };

  const duplicateResume = async (r) => {
    const full = await storageGet("resume:" + r.id);
    if (!full) return;
    const id = uid();
    const name = r.name + " (Copy)";
    await storageSet("resume:" + id, { ...full, id, name, updatedAt: Date.now() });
    await refreshIndex(id, name, r.level);
    loadLibrary();
    showToast("Resume duplicated");
  };

  const deleteResume = (r) => {
    setConfirm({
      msg: `Delete "${r.name}"? This cannot be undone.`,
      onYes: async () => {
        await storageDelete("resume:" + r.id);
        const idx = (await storageGet("resumes-index")) || [];
        await storageSet("resumes-index", idx.filter((x) => x.id !== r.id));
        loadLibrary();
        showToast("Resume deleted");
        setConfirm(null);
      },
    });
  };

  const newResume = (lvl) => {
    setData(emptyResume());
    setTemplate("classic");
    setColor(COLORS[0]);
    setLevel(lvl);
    setResumeName(lvl[0].toUpperCase() + lvl.slice(1) + " Resume");
    setCurrentId(null);
    setHistory([]); setHistIdx(-1);
    setScreen("editor");
    setMobileTab("form");
  };

  /* ---------- print / pdf ---------- */
  const handlePrint = () => {
    window.print();
  };

  /* ---------- data setters ---------- */
  const setPersonal = (patch) => setData((d) => ({ ...d, personal: { ...d.personal, ...patch } }));
  const setFooter = (patch) => setData((d) => ({ ...d, footer: { ...d.footer, ...patch } }));

  const onPhoto = (file) => {
    if (!file) return;
    const okType = ["image/jpeg", "image/jpg", "image/png", "image/webp"].includes(file.type);
    if (!okType) { showToast("Please upload a JPG, PNG or WEBP image.", "error"); return; }
    if (file.size > 6 * 1024 * 1024) { showToast("Photo is too large (max 6MB).", "error"); return; }
    const reader = new FileReader();
    reader.onload = () => setPersonal({ photo: reader.result, photoZoom: 1, photoX: 50, photoY: 50 });
    reader.onerror = () => showToast("Unable to load image. Please choose another photo.", "error");
    reader.readAsDataURL(file);
  };

  const toggleObjective = (text) => {
    setData((d) => {
      const has = d.objectiveSelected.includes(text);
      const nextSel = has ? d.objectiveSelected.filter((t) => t !== text) : [...d.objectiveSelected, text];
      return { ...d, objectiveSelected: nextSel, objectiveText: nextSel.join(" ") };
    });
  };

  const accent = color.hex;

  /* ---------- derived: section visibility for preview (content adaptation) ---------- */
  const has = (arr) => Array.isArray(arr) && arr.length > 0;

  /* ---------- render ---------- */
  if (screen === "home") return <Home onStart={() => setScreen("level")} onOpenLibrary={loadLibrary} />;

  if (screen === "level")
    return (
      <LevelSelect
        onBack={() => setScreen("home")}
        onPick={(lvl) => newResume(lvl)}
      />
    );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <style>{PRINT_CSS}</style>

      {/* ---------- Top bar ---------- */}
      <header className="no-print sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="flex items-center gap-2 px-3 sm:px-4 py-2.5">
          <button onClick={() => setScreen("home")} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500" aria-label="Back home">
            <ArrowLeft size={18} />
          </button>
          <input
            value={resumeName}
            onChange={(e) => setResumeName(e.target.value)}
            className="font-semibold text-slate-800 text-[15px] bg-transparent outline-none border-b border-transparent focus:border-slate-300 flex-1 min-w-0 truncate"
          />
          <span className="hidden sm:inline text-xs text-slate-400 shrink-0">
            {saveStatus === "saving" ? "Saving…" : saveStatus === "saved" ? "Saved ✓" : ""}
          </span>
          <div className="hidden sm:flex items-center gap-1 shrink-0">
            <IconBtn onClick={undo} disabled={histIdx <= 0} icon={<Undo2 size={17} />} label="Undo" />
            <IconBtn onClick={redo} disabled={histIdx >= history.length - 1} icon={<Redo2 size={17} />} label="Redo" />
            <IconBtn onClick={loadLibrary} icon={<FolderOpen size={17} />} label="My resumes" />
            <IconBtn onClick={handlePrint} icon={<Printer size={17} />} label="Print" />
            <button onClick={handlePrint} className="inline-flex items-center gap-1.5 bg-slate-900 text-white text-sm font-medium px-3.5 py-2 rounded-lg hover:bg-slate-800">
              <Download size={16} /> Download PDF
            </button>
          </div>
        </div>
      </header>

      {/* mobile tabs */}
      <div className="no-print sm:hidden flex border-b border-slate-200 bg-white sticky top-[52px] z-20">
        <button onClick={() => setMobileTab("form")} className={"flex-1 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 " + (mobileTab === "form" ? "text-slate-900 border-b-2 border-slate-900" : "text-slate-400")}>
          <PenLine size={15} /> Edit
        </button>
        <button onClick={() => setMobileTab("preview")} className={"flex-1 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 " + (mobileTab === "preview" ? "text-slate-900 border-b-2 border-slate-900" : "text-slate-400")}>
          <Eye size={15} /> Preview
        </button>
      </div>

      <div className="flex-1 flex flex-col sm:flex-row overflow-hidden">
        {/* ---------- FORM PANEL ---------- */}
        <div className={"no-print sm:w-[440px] sm:border-r border-slate-200 overflow-y-auto p-3 sm:p-4 bg-slate-50 " + (mobileTab === "form" ? "block" : "hidden sm:block")} style={{ maxHeight: "calc(100vh - 100px)" }}>
          {/* level + template + color quick controls */}
          <div className="flex gap-2 mb-3">
            <button onClick={() => setShowTemplates(true)} className="flex-1 inline-flex items-center justify-center gap-1.5 border border-slate-300 bg-white rounded-lg py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
              <LayoutTemplate size={15} /> Template
            </button>
            <div className="flex-1 relative">
              <div className="flex items-center gap-1.5 border border-slate-300 bg-white rounded-lg py-2 px-2.5 overflow-x-auto">
                <Palette size={14} className="text-slate-400 shrink-0" />
                {COLORS.map((c) => (
                  <button
                    key={c.name}
                    title={c.name}
                    onClick={() => setColor(c)}
                    className="w-5 h-5 rounded-full shrink-0 border-2"
                    style={{ background: c.hex, borderColor: color.name === c.name ? "#0f172a" : "transparent" }}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="flex gap-2 mb-3">
            {LEVELS.map((l) => (
              <button
                key={l.id}
                onClick={() => setLevel(l.id)}
                className={"flex-1 text-xs font-medium py-2 rounded-lg border " + (level === l.id ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-600 border-slate-300")}
              >
                {l.name}
              </button>
            ))}
          </div>

          <PersonalForm personal={data.personal} setPersonal={setPersonal} onPhoto={onPhoto} setData={setData} data={data} showToast={showToast} />

          <SectionCard title="Career Objective" subtitle="Pick one or more, or write your own">
            <div className="space-y-2 mb-3">
              {OBJECTIVES.map((o, i) => (
                <label key={i} className="flex items-start gap-2 text-sm text-slate-600 cursor-pointer">
                  <input type="checkbox" checked={data.objectiveSelected.includes(o)} onChange={() => toggleObjective(o)} className="mt-1" />
                  <span>{o}</span>
                </label>
              ))}
            </div>
            <Field label="Final objective text (editable)" hint="Selections above are combined here — edit freely, or clear and write your own.">
              <TextArea value={data.objectiveText} onChange={(e) => setData((d) => ({ ...d, objectiveText: e.target.value }))} placeholder="Write a custom career objective…" />
            </Field>
          </SectionCard>

          <SectionCard title="Academic Qualification">
            <CardRepeater
              items={data.education}
              onChange={(items) => setData((d) => ({ ...d, education: items }))}
              addLabel="Add Qualification"
              empty="No qualifications added yet."
              fields={[
                { key: "exam", label: "Exam / Qualification", placeholder: "e.g. B.Tech, Diploma, ITI" },
                { key: "board", label: "Board / University" },
                { key: "year", label: "Passing Year", placeholder: "e.g. 2022" },
                { key: "marks", label: "Percentage / Marks" },
                { key: "division", label: "Division" },
              ]}
            />
          </SectionCard>

          <SectionCard title="Professional Qualification" defaultOpen={false}>
            <CardRepeater
              items={data.professionalQualification}
              onChange={(items) => setData((d) => ({ ...d, professionalQualification: items }))}
              addLabel="Add Professional Qualification"
              empty="None added — this section stays hidden on the resume."
              fields={[
                { key: "exam", label: "Exam / Qualification" },
                { key: "board", label: "Board / University / Institute" },
                { key: "year", label: "Passing Year" },
                { key: "marks", label: "Percentage / Marks" },
                { key: "division", label: "Division" },
              ]}
            />
          </SectionCard>

          <SectionCard title="Extra Qualification" defaultOpen={false} subtitle="CCC, Tally, DCA, MS Office…">
            <TagInput items={data.extraQualification} onChange={(items) => setData((d) => ({ ...d, extraQualification: items }))} placeholder="e.g. Tally, CCC, MS Office" />
          </SectionCard>

          <SectionCard title="Work Experience">
            <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
              <input type="checkbox" checked={data.isFresher} onChange={(e) => setData((d) => ({ ...d, isFresher: e.target.checked }))} />
              I am a Fresher
            </label>
            {!data.isFresher && (
              <CardRepeater
                items={data.experience}
                onChange={(items) => setData((d) => ({ ...d, experience: items }))}
                addLabel="Add Experience"
                empty="No experience added yet."
                fields={[
                  { key: "company", label: "Company / Organization" },
                  { key: "position", label: "Job Position" },
                  { key: "location", label: "Location" },
                  { key: "start", label: "Start Date", type: "month" },
                  { key: "end", label: "End Date", type: "month", placeholder: "Leave blank if current" },
                  { key: "description", label: "Description / Responsibilities", type: "textarea", full: true },
                ]}
              />
            )}
          </SectionCard>

          {(level === "medium" || level === "high") && (
            <>
              <SectionCard title="Professional Summary">
                <TextArea value={data.summary} onChange={(e) => setData((d) => ({ ...d, summary: e.target.value }))} placeholder="A short, punchy summary of your professional profile…" />
              </SectionCard>

              <SectionCard title="Skills">
                <TagInput items={data.skills} onChange={(items) => setData((d) => ({ ...d, skills: items }))} placeholder="e.g. Communication, Teamwork" />
              </SectionCard>

              <SectionCard title="Technical Skills">
                <TagInput items={data.technicalSkills} onChange={(items) => setData((d) => ({ ...d, technicalSkills: items }))} placeholder="e.g. Excel, AutoCAD, HTML" />
              </SectionCard>

              {level === "high" && (
                <>
                  <SectionCard title="Programming Languages">
                    <TagInput items={data.programmingLanguages} onChange={(items) => setData((d) => ({ ...d, programmingLanguages: items }))} placeholder="e.g. Python, Java" />
                  </SectionCard>
                  <SectionCard title="Tools / Software">
                    <TagInput items={data.tools} onChange={(items) => setData((d) => ({ ...d, tools: items }))} placeholder="e.g. Git, AutoCAD, SAP" />
                  </SectionCard>
                </>
              )}

              <SectionCard title="Projects" defaultOpen={false}>
                <CardRepeater
                  items={data.projects}
                  onChange={(items) => setData((d) => ({ ...d, projects: items }))}
                  addLabel="Add Project"
                  empty="No projects added yet."
                  fields={[
                    { key: "name", label: "Project Name" },
                    { key: "role", label: "Role" },
                    { key: "client", label: "Client / Organization" },
                    { key: "tech", label: "Technology" },
                    { key: "duration", label: "Duration" },
                    { key: "description", label: "Description / Achievements", type: "textarea", full: true },
                  ]}
                />
              </SectionCard>

              <SectionCard title="Certifications" defaultOpen={false}>
                <CardRepeater
                  items={data.certifications}
                  onChange={(items) => setData((d) => ({ ...d, certifications: items }))}
                  addLabel="Add Certification"
                  empty="No certifications added yet."
                  fields={[
                    { key: "name", label: "Certificate Name" },
                    { key: "org", label: "Issuing Organization" },
                    { key: "year", label: "Year" },
                  ]}
                />
              </SectionCard>

              {level === "high" && (
                <>
                  <SectionCard title="Internship" defaultOpen={false}>
                    <CardRepeater
                      items={data.internship}
                      onChange={(items) => setData((d) => ({ ...d, internship: items }))}
                      addLabel="Add Internship"
                      empty="No internships added."
                      fields={[
                        { key: "org", label: "Organization" },
                        { key: "role", label: "Role" },
                        { key: "duration", label: "Duration" },
                        { key: "description", label: "Description", type: "textarea", full: true },
                      ]}
                    />
                  </SectionCard>
                  <SectionCard title="Professional Training" defaultOpen={false}>
                    <CardRepeater
                      items={data.training}
                      onChange={(items) => setData((d) => ({ ...d, training: items }))}
                      addLabel="Add Training"
                      empty="No training added."
                      fields={[
                        { key: "name", label: "Training Name" },
                        { key: "org", label: "Organization" },
                        { key: "year", label: "Year" },
                      ]}
                    />
                  </SectionCard>
                </>
              )}

              <SectionCard title="Achievements" defaultOpen={false}>
                <TagInput items={data.achievements} onChange={(items) => setData((d) => ({ ...d, achievements: items }))} placeholder="e.g. Employee of the Month" />
              </SectionCard>

              <SectionCard title="Languages" defaultOpen={false}>
                <CardRepeater
                  items={data.languages}
                  onChange={(items) => setData((d) => ({ ...d, languages: items }))}
                  addLabel="Add Language"
                  empty="No languages added."
                  fields={[
                    { key: "language", label: "Language" },
                    { key: "proficiency", label: "Proficiency", placeholder: "e.g. Fluent, Basic" },
                  ]}
                />
              </SectionCard>

              <SectionCard title="Strengths" defaultOpen={false}>
                <TagInput items={data.strengths} onChange={(items) => setData((d) => ({ ...d, strengths: items }))} placeholder="e.g. Punctual, Team player" />
              </SectionCard>

              <SectionCard title="References" defaultOpen={false} subtitle="Optional">
                <CardRepeater
                  items={data.references}
                  onChange={(items) => setData((d) => ({ ...d, references: items }))}
                  addLabel="Add Reference"
                  empty="No references added."
                  fields={[
                    { key: "name", label: "Name" },
                    { key: "designation", label: "Designation" },
                    { key: "contact", label: "Contact" },
                  ]}
                />
              </SectionCard>
            </>
          )}

          <SectionCard title="Declaration">
            <div className="space-y-2 mb-3">
              {DECLARATIONS.map((decl, i) => (
                <label key={i} className="flex items-start gap-2 text-sm text-slate-600 cursor-pointer">
                  <input
                    type="radio"
                    name="decl"
                    checked={!data.useCustomDeclaration && data.declarationSelected === decl}
                    onChange={() => setData((d) => ({ ...d, declarationSelected: decl, useCustomDeclaration: false }))}
                  />
                  <span>{decl}</span>
                </label>
              ))}
              <label className="flex items-start gap-2 text-sm text-slate-600 cursor-pointer">
                <input type="radio" name="decl" checked={data.useCustomDeclaration} onChange={() => setData((d) => ({ ...d, useCustomDeclaration: true }))} />
                <span>Write my own declaration</span>
              </label>
            </div>
            {data.useCustomDeclaration && (
              <TextArea value={data.declarationCustom} onChange={(e) => setData((d) => ({ ...d, declarationCustom: e.target.value }))} placeholder="Write your custom declaration…" />
            )}
          </SectionCard>

          <SectionCard title="Footer — Date, Place & Signature">
            <div className="grid grid-cols-2 gap-2">
              <Field label="Date"><TextInput type="date" value={data.footer.date} onChange={(e) => setFooter({ date: e.target.value })} /></Field>
              <Field label="Place"><TextInput value={data.footer.place} onChange={(e) => setFooter({ place: e.target.value })} placeholder="e.g. Lucknow" /></Field>
            </div>
            <Field label="Signature Name"><TextInput value={data.footer.signatureName} onChange={(e) => setFooter({ signatureName: e.target.value })} placeholder="Defaults to your full name" /></Field>
          </SectionCard>

          <div className="h-16 sm:h-4" />
        </div>

        {/* ---------- PREVIEW PANEL ---------- */}
        <div className={"flex-1 overflow-auto bg-slate-100 flex flex-col items-center py-6 px-3 " + (mobileTab === "preview" ? "block" : "hidden sm:flex")}>
          <div className="no-print flex items-center gap-2 mb-4 bg-white border border-slate-200 rounded-full px-2 py-1 shadow-sm sticky top-2 z-10">
            <button onClick={() => setZoom((z) => Math.max(0.25, z - 0.08))} className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500"><ZoomOut size={16} /></button>
            <span className="text-xs text-slate-500 w-10 text-center">{Math.round(zoom * 100)}%</span>
            <button onClick={() => setZoom((z) => Math.min(1.1, z + 0.08))} className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500"><ZoomIn size={16} /></button>
            <span className="w-px h-4 bg-slate-200 mx-1" />
            <button onClick={() => setZoom(0.42)} className="text-xs text-slate-500 px-2 hover:text-slate-800">Fit</button>
          </div>

          <div style={{ width: 794 * zoom, height: 1123 * zoom }}>
            <div id="a4-page" style={{ width: 794, height: 1123, transform: `scale(${zoom})`, transformOrigin: "top left" }} className="bg-white shadow-lg">
              <ResumePreview data={data} level={level} template={template} accent={accent} />
            </div>
          </div>
          <p className="no-print text-xs text-slate-400 mt-4 text-center max-w-sm">
            This is a true A4 page (210×297mm) at {Math.round(zoom * 100)}% zoom. Zoom only changes the view — printing/PDF always uses full A4 size.
          </p>
        </div>
      </div>

      {/* ---------- Mobile sticky action bar ---------- */}
      <div className="no-print sm:hidden sticky bottom-0 bg-white border-t border-slate-200 flex items-center justify-around py-2 px-2 z-30">
        <IconBtn onClick={undo} disabled={histIdx <= 0} icon={<Undo2 size={18} />} label="Undo" stacked />
        <IconBtn onClick={redo} disabled={histIdx >= history.length - 1} icon={<Redo2 size={18} />} label="Redo" stacked />
        <IconBtn onClick={loadLibrary} icon={<FolderOpen size={18} />} label="Saved" stacked />
        <IconBtn onClick={handlePrint} icon={<Printer size={18} />} label="Print" stacked />
        <button onClick={handlePrint} className="flex flex-col items-center gap-0.5 text-slate-900">
          <Download size={18} />
          <span className="text-[10px] font-medium">PDF</span>
        </button>
      </div>

      {/* ---------- Print area (mirrors preview, full scale, hidden on screen) ---------- */}
      <div id="print-area">
        <ResumePreview data={data} level={level} template={template} accent={accent} />
      </div>

      {/* ---------- Template picker modal ---------- */}
      {showTemplates && (
        <Modal onClose={() => setShowTemplates(false)} title="Choose a Template">
          <div className="grid grid-cols-2 gap-3">
            {TEMPLATES.map((t) => (
              <button
                key={t.id}
                onClick={() => { setTemplate(t.id); setShowTemplates(false); }}
                className={"text-left rounded-xl border-2 p-3 hover:border-slate-400 " + (template === t.id ? "border-slate-900" : "border-slate-200")}
              >
                <div className="aspect-[210/297] bg-slate-50 rounded-md mb-2 overflow-hidden border border-slate-200">
                  <div style={{ transform: "scale(0.19)", transformOrigin: "top left", width: 794, height: 1123 }}>
                    <ResumePreview data={SAMPLE_DATA} level="medium" template={t.id} accent={accent} />
                  </div>
                </div>
                <div className="font-semibold text-sm text-slate-800">{t.name}</div>
                <div className="text-xs text-slate-500">{t.desc}</div>
              </button>
            ))}
          </div>
        </Modal>
      )}

      {/* ---------- Library modal ---------- */}
      {showLibrary && (
        <Modal onClose={() => setShowLibrary(false)} title="My Saved Resumes">
          {savedList.length === 0 ? (
            <p className="text-sm text-slate-500 py-6 text-center">No saved resumes yet. Start editing and it'll be saved here automatically.</p>
          ) : (
            <div className="space-y-2">
              {savedList.map((r) => (
                <div key={r.id} className="flex items-center gap-2 border border-slate-200 rounded-lg p-3">
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm text-slate-800 truncate">{r.name}</div>
                    <div className="text-xs text-slate-400 capitalize">{r.level} details · {new Date(r.updatedAt).toLocaleString()}</div>
                  </div>
                  <button onClick={() => openResume(r.id)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500" title="Open"><FolderOpen size={16} /></button>
                  <button onClick={() => duplicateResume(r)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500" title="Duplicate"><Copy size={16} /></button>
                  <button onClick={() => deleteResume(r)} className="p-2 rounded-lg hover:bg-red-50 text-red-500" title="Delete"><Trash2 size={16} /></button>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {/* ---------- Confirm modal ---------- */}
      {confirm && (
        <Modal onClose={() => setConfirm(null)} title="Please confirm">
          <div className="flex items-start gap-3 mb-4">
            <AlertTriangle className="text-amber-500 shrink-0 mt-0.5" size={20} />
            <p className="text-sm text-slate-600">{confirm.msg}</p>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setConfirm(null)} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
            <button onClick={confirm.onYes} className="px-4 py-2 rounded-lg text-sm font-medium bg-red-600 text-white hover:bg-red-700">Delete</button>
          </div>
        </Modal>
      )}

      <Toast toast={toast} />
    </div>
  );
}

/* ----------------------------------------------------------------------
   HOME + LEVEL SELECT
---------------------------------------------------------------------- */

function Home({ onStart, onOpenLibrary }) {
  return (
    <div className="min-h-screen bg-[#0F1B2D] text-white flex flex-col items-center justify-center px-6 py-16 text-center">
      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center font-bold text-lg mb-6 text-slate-900">Maa</div>
      <h1 className="text-3xl sm:text-4xl font-bold mb-2">Maa Enterprises</h1>
      <p className="text-slate-400 mb-10">Professional Resume &amp; CV Maker</p>
      <button onClick={onStart} className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold px-8 py-3.5 rounded-full text-[15px] shadow-lg shadow-amber-500/20">
        Create Job Resume / CV
      </button>
      <button onClick={onOpenLibrary} className="mt-4 text-slate-400 text-sm hover:text-white inline-flex items-center gap-1.5">
        <FolderOpen size={15} /> Open a saved resume
      </button>
      <p className="mt-16 text-xs text-slate-500 max-w-sm">Free to use. Your data stays on this device — nothing is uploaded, no login required.</p>
    </div>
  );
}

function LevelSelect({ onBack, onPick }) {
  return (
    <div className="min-h-screen bg-slate-50 px-5 py-10">
      <button onClick={onBack} className="text-slate-500 text-sm inline-flex items-center gap-1.5 mb-8"><ArrowLeft size={15} /> Back</button>
      <h2 className="text-2xl font-bold text-slate-900 mb-1 text-center">Choose Resume Detail Level</h2>
      <p className="text-slate-500 text-center mb-10 text-sm">You can add or remove sections at any time later.</p>
      <div className="max-w-3xl mx-auto grid sm:grid-cols-3 gap-4">
        {LEVELS.map((l) => (
          <div key={l.id} className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col">
            <h3 className="font-bold text-lg text-slate-900 mb-2">{l.name}</h3>
            <p className="text-sm text-slate-500 flex-1 mb-5">{l.desc}</p>
            <button onClick={() => onPick(l.id)} className="bg-slate-900 hover:bg-slate-800 text-white font-medium py-2.5 rounded-lg text-sm">
              Create Resume →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------
   PERSONAL DETAILS FORM
---------------------------------------------------------------------- */

function PersonalForm({ personal, setPersonal, onPhoto, showToast }) {
  const fileRef = useRef(null);
  return (
    <SectionCard title="Personal Details">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-20 h-24 rounded-lg overflow-hidden bg-slate-100 border border-slate-200 shrink-0 flex items-center justify-center">
          {personal.photo ? (
            <img src={personal.photo} alt="Profile" style={{ objectFit: "cover", width: "100%", height: "100%", objectPosition: `${personal.photoX}% ${personal.photoY}%`, transform: `scale(${personal.photoZoom})` }} />
          ) : (
            <ImageIcon size={22} className="text-slate-300" />
          )}
        </div>
        <div className="flex-1">
          <div className="flex gap-2 mb-2">
            <button type="button" onClick={() => fileRef.current.click()} className="inline-flex items-center gap-1.5 text-sm font-medium border border-slate-300 rounded-lg px-3 py-1.5 hover:bg-slate-50">
              <Upload size={14} /> {personal.photo ? "Replace" : "Upload"}
            </button>
            {personal.photo && (
              <button type="button" onClick={() => setPersonal({ photo: null })} className="inline-flex items-center gap-1.5 text-sm font-medium text-red-500 border border-red-200 rounded-lg px-3 py-1.5 hover:bg-red-50">
                <X size={14} /> Remove
              </button>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/jpeg,image/jpg,image/png,image/webp" className="hidden" onChange={(e) => onPhoto(e.target.files[0])} />
          {personal.photo && (
            <div className="grid grid-cols-3 gap-2 mt-1">
              <label className="text-[10px] text-slate-400">Zoom
                <input type="range" min="1" max="2" step="0.05" value={personal.photoZoom} onChange={(e) => setPersonal({ photoZoom: +e.target.value })} className="w-full" />
              </label>
              <label className="text-[10px] text-slate-400">Position X
                <input type="range" min="0" max="100" value={personal.photoX} onChange={(e) => setPersonal({ photoX: +e.target.value })} className="w-full" />
              </label>
              <label className="text-[10px] text-slate-400">Position Y
                <input type="range" min="0" max="100" value={personal.photoY} onChange={(e) => setPersonal({ photoY: +e.target.value })} className="w-full" />
              </label>
            </div>
          )}
          <p className="text-[11px] text-slate-400 mt-1">JPG, PNG or WEBP. Optional — the resume adapts if left empty.</p>
        </div>
      </div>

      <Field label="Full Name" required><TextInput value={personal.fullName} onChange={(e) => setPersonal({ fullName: e.target.value })} placeholder="e.g. Rajesh Kumar" /></Field>
      <Field label="Address"><TextArea value={personal.address} onChange={(e) => setPersonal({ address: e.target.value })} placeholder="House no., street, city, state, PIN" /></Field>

      <div className="grid grid-cols-2 gap-2">
        <Field label="Mobile Number" error={!isValidMobile(personal.mobile) ? "Enter a valid 10-digit Indian mobile number." : null}>
          <TextInput value={personal.mobile} onChange={(e) => setPersonal({ mobile: e.target.value.replace(/[^\d]/g, "").slice(0, 10) })} placeholder="98XXXXXXXX" error={!isValidMobile(personal.mobile)} />
        </Field>
        <Field label="WhatsApp Number" error={!isValidMobile(personal.whatsapp) ? "Enter a valid 10-digit number." : null}>
          <TextInput value={personal.whatsapp} onChange={(e) => setPersonal({ whatsapp: e.target.value.replace(/[^\d]/g, "").slice(0, 10) })} placeholder="98XXXXXXXX" error={!isValidMobile(personal.whatsapp)} />
        </Field>
      </div>

      <Field label="Email" error={!isValidEmail(personal.email) ? "Enter a valid email address." : null}>
        <TextInput type="email" value={personal.email} onChange={(e) => setPersonal({ email: e.target.value })} placeholder="you@example.com" error={!isValidEmail(personal.email)} />
      </Field>

      <div className="grid grid-cols-2 gap-2">
        <Field label="Date of Birth" error={!isValidDOB(personal.dob) ? "Date of birth cannot be in the future." : null}>
          <TextInput type="date" value={personal.dob} onChange={(e) => setPersonal({ dob: e.target.value })} error={!isValidDOB(personal.dob)} />
        </Field>
        <Field label="Nationality"><TextInput value={personal.nationality} onChange={(e) => setPersonal({ nationality: e.target.value })} /></Field>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Field label="Father's Name"><TextInput value={personal.fatherName} onChange={(e) => setPersonal({ fatherName: e.target.value })} /></Field>
        <Field label="Mother's Name"><TextInput value={personal.motherName} onChange={(e) => setPersonal({ motherName: e.target.value })} /></Field>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Field label="Gender">
          <select value={personal.gender} onChange={(e) => setPersonal({ gender: e.target.value })} className={inputCls}>
            <option value="">Select</option><option>Male</option><option>Female</option><option>Other</option>
          </select>
        </Field>
        <Field label="Marital Status">
          <select value={personal.maritalStatus} onChange={(e) => setPersonal({ maritalStatus: e.target.value })} className={inputCls}>
            <option value="">Select</option><option>Single</option><option>Married</option>
          </select>
        </Field>
      </div>

      <Field label="Languages Known" hint="Comma separated, e.g. Hindi, English"><TextInput value={personal.languagesKnown} onChange={(e) => setPersonal({ languagesKnown: e.target.value })} /></Field>
      <Field label="Hobbies" hint="Comma separated"><TextInput value={personal.hobbies} onChange={(e) => setPersonal({ hobbies: e.target.value })} /></Field>
    </SectionCard>
  );
}

/* ----------------------------------------------------------------------
   SHARED UI HELPERS
---------------------------------------------------------------------- */

function IconBtn({ onClick, disabled, icon, label, stacked }) {
  if (stacked) {
    return (
      <button onClick={onClick} disabled={disabled} className={"flex flex-col items-center gap-0.5 " + (disabled ? "text-slate-300" : "text-slate-600")}>
        {icon}<span className="text-[10px] font-medium">{label}</span>
      </button>
    );
  }
  return (
    <button onClick={onClick} disabled={disabled} title={label} className={"p-2 rounded-lg hover:bg-slate-100 " + (disabled ? "text-slate-300" : "text-slate-500")}>
      {icon}
    </button>
  );
}

function Modal({ title, children, onClose }) {
  return (
    <div className="no-print fixed inset-0 z-[90] bg-black/40 flex items-end sm:items-center justify-center p-0 sm:p-6" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-white rounded-t-2xl sm:rounded-2xl w-full sm:max-w-lg max-h-[85vh] overflow-y-auto p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-slate-900">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------
   RESUME PREVIEW — renders the shared data model into the chosen template
---------------------------------------------------------------------- */

const SAMPLE_DATA = (() => {
  const d = emptyResume();
  d.personal.fullName = "Rajesh Kumar";
  d.personal.address = "12 MG Road, Lucknow, Uttar Pradesh";
  d.personal.mobile = "9876543210";
  d.personal.dob = "1998-04-12";
  d.objectiveText = OBJECTIVES[0];
  d.education = [{ id: "1", exam: "B.Tech (CSE)", board: "AKTU", year: "2021", marks: "78%", division: "First" }];
  d.isFresher = false;
  d.experience = [{ id: "1", company: "Infotech Solutions", position: "Software Engineer", location: "Noida", start: "2021-07", end: "", description: "Building and maintaining web applications." }];
  d.skills = ["Communication", "Teamwork"];
  d.declarationSelected = DECLARATIONS[0];
  return d;
})();

function ResumePreview({ data, level, template, accent }) {
  const p = data.personal;
  const objective = data.objectiveText?.trim();
  const declaration = data.useCustomDeclaration ? data.declarationCustom : data.declarationSelected;
  const isFresherShown = data.isFresher || data.experience.length === 0;

  const sections = buildSections(data, level);

  const props = { data, p, objective, declaration, isFresherShown, sections, accent, level };

  if (template === "modern") return <ModernTemplate {...props} />;
  if (template === "sidebar") return <SidebarTemplate {...props} />;
  if (template === "minimal") return <MinimalTemplate {...props} />;
  return <ClassicTemplate {...props} />;
}

/** Build an ordered list of visible sections (content adaptation — never show empty headings). */
function buildSections(d, level) {
  const list = [];
  if (d.professionalQualification.length) list.push({ key: "profQual", title: "Professional Qualification", type: "table", rows: d.professionalQualification });
  if (d.extraQualification.length) list.push({ key: "extraQual", title: "Extra Qualification", type: "tags", items: d.extraQualification });
  if (level !== "low") {
    if (d.summary?.trim()) list.push({ key: "summary", title: "Professional Summary", type: "text", text: d.summary });
    if (d.skills.length) list.push({ key: "skills", title: "Skills", type: "tags", items: d.skills });
    if (d.technicalSkills.length) list.push({ key: "techSkills", title: "Technical Skills", type: "tags", items: d.technicalSkills });
    if (d.programmingLanguages.length) list.push({ key: "progLang", title: "Programming Languages", type: "tags", items: d.programmingLanguages });
    if (d.tools.length) list.push({ key: "tools", title: "Tools / Software", type: "tags", items: d.tools });
    if (d.projects.length) list.push({ key: "projects", title: "Projects", type: "cards", rows: d.projects, template: ["name", "role", "tech", "duration", "client", "description"] });
    if (d.certifications.length) list.push({ key: "certs", title: "Certifications", type: "list3", rows: d.certifications, cols: ["name", "org", "year"] });
    if (d.internship.length) list.push({ key: "internship", title: "Internship", type: "cards", rows: d.internship, template: ["org", "role", "duration", "description"] });
    if (d.training.length) list.push({ key: "training", title: "Professional Training", type: "list3", rows: d.training, cols: ["name", "org", "year"] });
    if (d.achievements.length) list.push({ key: "achievements", title: "Achievements", type: "tags", items: d.achievements });
    if (d.languages.length) list.push({ key: "languages", title: "Languages", type: "list2", rows: d.languages, cols: ["language", "proficiency"] });
    if (d.strengths.length) list.push({ key: "strengths", title: "Strengths", type: "tags", items: d.strengths });
    if (d.references.length) list.push({ key: "references", title: "References", type: "list3", rows: d.references, cols: ["name", "designation", "contact"] });
  }
  return list;
}

/* ---- small building blocks shared across templates ---- */

function SecTitle({ children, accent, style }) {
  return (
    <div style={{ borderBottom: `2px solid ${accent}`, color: accent, ...style }} className="uppercase text-[11px] font-bold tracking-wider mb-1.5 pb-0.5 mt-3">
      {children}
    </div>
  );
}

function RenderSection({ s, accent }) {
  if (s.type === "text") return <p className="text-[11px] leading-relaxed text-slate-700">{s.text}</p>;
  if (s.type === "tags")
    return (
      <div className="flex flex-wrap gap-1.5">
        {s.items.map((t, i) => <span key={i} className="text-[10.5px] bg-slate-100 rounded px-2 py-0.5 text-slate-700">{t}</span>)}
      </div>
    );
  if (s.type === "list2" || s.type === "list3")
    return (
      <div className="text-[11px] text-slate-700 space-y-0.5">
        {s.rows.map((r, i) => <div key={i}>{s.cols.map((c) => r[c]).filter(Boolean).join(" — ")}</div>)}
      </div>
    );
  if (s.type === "table")
    return (
      <table className="w-full text-[10.5px] border-collapse">
        <tbody>
          {s.rows.map((r, i) => (
            <tr key={i} className="border-b border-slate-100">
              <td className="py-1 pr-2 font-medium text-slate-800">{r.exam}</td>
              <td className="py-1 pr-2 text-slate-600">{r.board}</td>
              <td className="py-1 pr-2 text-slate-600">{r.year}</td>
              <td className="py-1 text-slate-600">{r.marks}{r.division ? ` (${r.division})` : ""}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  if (s.type === "cards")
    return (
      <div className="space-y-2">
        {s.rows.map((r, i) => (
          <div key={i} className="text-[11px]">
            <div className="font-semibold text-slate-800">
              {r.name || r.org} {r.role ? `— ${r.role}` : ""}
            </div>
            <div className="text-[10px] text-slate-500">{[r.client, r.tech, r.duration].filter(Boolean).join(" · ")}</div>
            {r.description && <p className="text-slate-600 mt-0.5 leading-snug">{r.description}</p>}
          </div>
        ))}
      </div>
    );
  return null;
}

function EducationTable({ education, accent }) {
  if (!education.length) return null;
  return (
    <table className="w-full text-[10.5px] border-collapse">
      <thead>
        <tr style={{ background: accent + "14" }}>
          <th className="text-left py-1 px-1.5 font-semibold" style={{ color: accent }}>Exam</th>
          <th className="text-left py-1 px-1.5 font-semibold" style={{ color: accent }}>Board/University</th>
          <th className="text-left py-1 px-1.5 font-semibold" style={{ color: accent }}>Year</th>
          <th className="text-left py-1 px-1.5 font-semibold" style={{ color: accent }}>Marks</th>
          <th className="text-left py-1 px-1.5 font-semibold" style={{ color: accent }}>Division</th>
        </tr>
      </thead>
      <tbody>
        {education.map((r) => (
          <tr key={r.id} className="border-b border-slate-100">
            <td className="py-1 px-1.5">{r.exam}</td>
            <td className="py-1 px-1.5">{r.board}</td>
            <td className="py-1 px-1.5">{r.year}</td>
            <td className="py-1 px-1.5">{r.marks}</td>
            <td className="py-1 px-1.5">{r.division}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ExperienceBlock({ p, isFresherShown, experience, accent }) {
  if (isFresherShown) {
    return <div className="text-[11px] font-semibold" style={{ color: accent }}>FRESHER</div>;
  }
  return (
    <div className="space-y-2">
      {experience.map((e) => (
        <div key={e.id} className="text-[11px]">
          <div className="flex justify-between font-semibold text-slate-800">
            <span>{e.position}{e.company ? ` — ${e.company}` : ""}</span>
            <span className="text-[10px] font-normal text-slate-500">{e.start}{e.end ? ` – ${e.end}` : e.start ? " – Present" : ""}</span>
          </div>
          {e.location && <div className="text-[10px] text-slate-500">{e.location}</div>}
          {e.description && <p className="text-slate-600 mt-0.5 leading-snug">{e.description}</p>}
        </div>
      ))}
    </div>
  );
}

function FooterBlock({ data, accent }) {
  const { footer, declaration, personal } = data;
  return (
    <div className="mt-4">
      {declaration && (
        <>
          <SecTitle accent={accent}>Declaration</SecTitle>
          <p className="text-[10.5px] text-slate-600 leading-relaxed mb-2">{declaration}</p>
        </>
      )}
      <div className="flex justify-between items-end mt-3 text-[10.5px] text-slate-600">
        <div>
          {footer.date && <div>Date: {footer.date}</div>}
          {footer.place && <div>Place: {footer.place}</div>}
        </div>
        <div className="text-right">
          {footer.signatureImg && <img src={footer.signatureImg} alt="Signature" className="h-8 mb-1 ml-auto" />}
          <div className="font-semibold text-slate-800">{footer.signatureName || personal.fullName || " "}</div>
        </div>
      </div>
    </div>
  );
}

function PhotoBox({ personal, size = 88, radius = 4 }) {
  return (
    <div style={{ width: size, height: size * 1.2, borderRadius: radius }} className="bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
      {personal.photo ? (
        <img src={personal.photo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: `${personal.photoX}% ${personal.photoY}%`, transform: `scale(${personal.photoZoom})` }} />
      ) : null}
    </div>
  );
}

/* ---- CLASSIC ---- */
function ClassicTemplate({ p, objective, isFresherShown, data, sections, accent }) {
  return (
    <div style={{ fontFamily: "Georgia, 'Times New Roman', serif", width: 794, height: 1123, padding: "42px 48px", boxSizing: "border-box", color: "#1f2937" }}>
      <div className="flex justify-between items-start pb-3 mb-3" style={{ borderBottom: `3px double ${accent}` }}>
        <div>
          <h1 className="text-2xl font-bold tracking-wide" style={{ color: accent }}>{p.fullName || "Your Name"}</h1>
          <div className="text-[11px] text-slate-500 mt-1">{[p.address, p.mobile, p.email].filter(Boolean).join("  |  ")}</div>
        </div>
        {p.photo && <PhotoBox personal={p} size={88} radius={4} />}
      </div>

      {objective && <><SecTitle accent={accent}>Career Objective</SecTitle><p className="text-[11px] leading-relaxed text-slate-700">{objective}</p></>}

      <SecTitle accent={accent}>Personal Details</SecTitle>
      <div className="grid grid-cols-2 gap-x-4 text-[10.5px] text-slate-700">
        {p.dob && <div><b>Date of Birth:</b> {p.dob}</div>}
        {p.fatherName && <div><b>Father's Name:</b> {p.fatherName}</div>}
        {p.motherName && <div><b>Mother's Name:</b> {p.motherName}</div>}
        {p.gender && <div><b>Gender:</b> {p.gender}</div>}
        {p.maritalStatus && <div><b>Marital Status:</b> {p.maritalStatus}</div>}
        {p.nationality && <div><b>Nationality:</b> {p.nationality}</div>}
        {p.languagesKnown && <div><b>Languages Known:</b> {p.languagesKnown}</div>}
        {p.hobbies && <div><b>Hobbies:</b> {p.hobbies}</div>}
      </div>

      {data.education.length > 0 && <><SecTitle accent={accent}>Academic Qualification</SecTitle><EducationTable education={data.education} accent={accent} /></>}

      <SecTitle accent={accent}>Work Experience</SecTitle>
      <ExperienceBlock p={p} isFresherShown={isFresherShown} experience={data.experience} accent={accent} />

      {sections.map((s) => (
        <div key={s.key}><SecTitle accent={accent}>{s.title}</SecTitle><RenderSection s={s} accent={accent} /></div>
      ))}

      <FooterBlock data={data} accent={accent} />
    </div>
  );
}

/* ---- MODERN ---- */
function ModernTemplate({ p, objective, isFresherShown, data, sections, accent }) {
  return (
    <div style={{ fontFamily: "Arial, Helvetica, sans-serif", width: 794, height: 1123, boxSizing: "border-box", color: "#1f2937" }}>
      <div style={{ background: accent }} className="text-white px-12 py-8 flex items-center gap-5">
        {p.photo && <PhotoBox personal={p} size={80} radius={999} />}
        <div>
          <h1 className="text-2xl font-bold">{p.fullName || "Your Name"}</h1>
          <div className="text-[11px] opacity-90 mt-1">{[p.address, p.mobile, p.email].filter(Boolean).join("   |   ")}</div>
        </div>
      </div>
      <div className="px-12 py-6">
        {objective && <><SecTitle accent={accent}>Career Objective</SecTitle><p className="text-[11px] leading-relaxed text-slate-700">{objective}</p></>}

        <SecTitle accent={accent}>Personal Details</SecTitle>
        <div className="grid grid-cols-2 gap-x-4 text-[10.5px] text-slate-700">
          {p.dob && <div><b>DOB:</b> {p.dob}</div>}
          {p.fatherName && <div><b>Father's Name:</b> {p.fatherName}</div>}
          {p.gender && <div><b>Gender:</b> {p.gender}</div>}
          {p.maritalStatus && <div><b>Marital Status:</b> {p.maritalStatus}</div>}
          {p.nationality && <div><b>Nationality:</b> {p.nationality}</div>}
          {p.languagesKnown && <div><b>Languages:</b> {p.languagesKnown}</div>}
        </div>

        {data.education.length > 0 && <><SecTitle accent={accent}>Academic Qualification</SecTitle><EducationTable education={data.education} accent={accent} /></>}

        <SecTitle accent={accent}>Work Experience</SecTitle>
        <ExperienceBlock p={p} isFresherShown={isFresherShown} experience={data.experience} accent={accent} />

        {sections.map((s) => (
          <div key={s.key}><SecTitle accent={accent}>{s.title}</SecTitle><RenderSection s={s} accent={accent} /></div>
        ))}

        <FooterBlock data={data} accent={accent} />
      </div>
    </div>
  );
}

/* ---- SIDEBAR ---- */
function SidebarTemplate({ p, objective, isFresherShown, data, sections, accent }) {
  const sideKeys = ["skills", "techSkills", "progLang", "tools", "languages", "strengths"];
  const sideSections = sections.filter((s) => sideKeys.includes(s.key));
  const mainSections = sections.filter((s) => !sideKeys.includes(s.key));
  return (
    <div style={{ fontFamily: "Arial, Helvetica, sans-serif", width: 794, height: 1123, boxSizing: "border-box", color: "#1f2937", display: "flex" }}>
      <div style={{ background: accent, width: 250 }} className="text-white px-6 py-8 shrink-0">
        {p.photo && <div className="mb-4"><PhotoBox personal={p} size={110} radius={999} /></div>}
        <h1 className="text-xl font-bold leading-tight">{p.fullName || "Your Name"}</h1>
        <div className="text-[10px] opacity-90 mt-3 space-y-1">
          {p.mobile && <div>📞 {p.mobile}</div>}
          {p.email && <div>✉ {p.email}</div>}
          {p.address && <div>📍 {p.address}</div>}
        </div>
        <div className="text-[10px] opacity-90 mt-4 space-y-1">
          {p.dob && <div><b>DOB:</b> {p.dob}</div>}
          {p.gender && <div><b>Gender:</b> {p.gender}</div>}
          {p.maritalStatus && <div><b>Status:</b> {p.maritalStatus}</div>}
          {p.nationality && <div><b>Nationality:</b> {p.nationality}</div>}
          {p.hobbies && <div><b>Hobbies:</b> {p.hobbies}</div>}
        </div>
        {sideSections.map((s) => (
          <div key={s.key} className="mt-4">
            <div className="uppercase text-[10px] font-bold tracking-wider mb-1 pb-1 border-b border-white/30">{s.title}</div>
            <div className="text-[10px] opacity-95 space-y-0.5">
              {s.type === "tags" ? s.items.map((t, i) => <div key={i}>• {t}</div>) : <RenderSection s={s} accent="#fff" />}
            </div>
          </div>
        ))}
      </div>
      <div className="flex-1 px-8 py-8 overflow-hidden">
        {objective && <><SecTitle accent={accent}>Career Objective</SecTitle><p className="text-[11px] leading-relaxed text-slate-700">{objective}</p></>}
        {data.education.length > 0 && <><SecTitle accent={accent}>Academic Qualification</SecTitle><EducationTable education={data.education} accent={accent} /></>}
        <SecTitle accent={accent}>Work Experience</SecTitle>
        <ExperienceBlock p={p} isFresherShown={isFresherShown} experience={data.experience} accent={accent} />
        {mainSections.map((s) => (
          <div key={s.key}><SecTitle accent={accent}>{s.title}</SecTitle><RenderSection s={s} accent={accent} /></div>
        ))}
        <FooterBlock data={data} accent={accent} />
      </div>
    </div>
  );
}

/* ---- MINIMAL ---- */
function MinimalTemplate({ p, objective, isFresherShown, data, sections, accent }) {
  return (
    <div style={{ fontFamily: "'Helvetica Neue', Arial, sans-serif", width: 794, height: 1123, padding: "46px 52px", boxSizing: "border-box", color: "#111827" }}>
      <div className="flex justify-between items-center mb-5">
        <div>
          <h1 className="text-[26px] font-light tracking-wide">{p.fullName || "Your Name"}</h1>
          <div className="text-[10.5px] text-slate-500 mt-1 tracking-wide">{[p.mobile, p.email, p.address].filter(Boolean).join("   ·   ")}</div>
        </div>
        {p.photo && <div style={{ width: 70, height: 70 }} className="rounded-full overflow-hidden border"><img src={p.photo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: `${p.photoX}% ${p.photoY}%`, transform: `scale(${p.photoZoom})` }} /></div>}
      </div>
      <div style={{ height: 1, background: "#e5e7eb" }} className="mb-4" />

      {objective && <p className="text-[11px] leading-relaxed text-slate-600 italic mb-4">{objective}</p>}

      <MinimalSec title="Personal Details" accent={accent}>
        <div className="grid grid-cols-2 gap-x-4 text-[10.5px] text-slate-700">
          {p.dob && <div>DOB — {p.dob}</div>}
          {p.gender && <div>Gender — {p.gender}</div>}
          {p.maritalStatus && <div>Status — {p.maritalStatus}</div>}
          {p.nationality && <div>Nationality — {p.nationality}</div>}
          {p.languagesKnown && <div>Languages — {p.languagesKnown}</div>}
          {p.hobbies && <div>Hobbies — {p.hobbies}</div>}
        </div>
      </MinimalSec>

      {data.education.length > 0 && <MinimalSec title="Academic Qualification" accent={accent}><EducationTable education={data.education} accent={accent} /></MinimalSec>}

      <MinimalSec title="Work Experience" accent={accent}>
        <ExperienceBlock p={p} isFresherShown={isFresherShown} experience={data.experience} accent={accent} />
      </MinimalSec>

      {sections.map((s) => (
        <MinimalSec key={s.key} title={s.title} accent={accent}><RenderSection s={s} accent={accent} /></MinimalSec>
      ))}

      <FooterBlock data={data} accent={accent} />
    </div>
  );
}
function MinimalSec({ title, accent, children }) {
  return (
    <div className="mb-4">
      <div className="text-[10px] font-semibold tracking-[0.15em] uppercase mb-1.5" style={{ color: accent }}>{title}</div>
      {children}
    </div>
  );
}

/* ----------------------------------------------------------------------
   PRINT CSS
---------------------------------------------------------------------- */
const PRINT_CSS = `
#print-area { display: none; }
@media print {
  @page { size: A4; margin: 0; }
  body * { visibility: hidden; }
  #print-area, #print-area * { visibility: visible; }
  #print-area { display: block !important; position: absolute; top: 0; left: 0; width: 210mm; }
  .no-print { display: none !important; }
}
`;
