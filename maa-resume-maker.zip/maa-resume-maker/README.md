# Maa Enterprises — Resume & CV Maker

Free, mobile-first Resume/CV builder. Pure client-side — no backend, no login, no payment.
Saved resumes live in the visitor's own browser (`localStorage`).

## Run locally

```bash
npm install
npm run dev
```

## Deploy to Vercel (2 minutes)

**Option A — GitHub (recommended)**
1. Push this folder to a new GitHub repo.
2. Go to https://vercel.com → **Add New Project** → import that repo.
3. Vercel auto-detects Vite. Leave defaults (Build Command: `npm run build`, Output: `dist`).
4. Click **Deploy**. Done — you get a live `.vercel.app` URL, free.

**Option B — Vercel CLI (no GitHub needed)**
```bash
npm install -g vercel
cd maa-resume-maker
vercel
```
Follow the prompts (press Enter for defaults). It deploys straight from your machine.

## Deploy to GitHub Pages / Firebase Hosting instead

```bash
npm run build
```
This creates a `dist/` folder — upload its contents to any static host
(GitHub Pages, Firebase Hosting, Netlify, Cloudflare Pages, etc.).
